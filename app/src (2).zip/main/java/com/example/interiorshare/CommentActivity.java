package com.example.interiorshare;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.ComponentActivity;
import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Comment;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.lang.reflect.Array;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import java.util.List;

import javax.net.ssl.HttpsURLConnection;

public class CommentActivity extends AppCompatActivity {

    final private String TAG = getClass().getSimpleName();
    ArrayList<String> ListViewItem = new ArrayList<String>();
    // 사용할 컴포넌트 선언
    TextView title, content, date;
    LinearLayout comment_layout;
    EditText comment_et;
    Button reg_button, delete_button;

    String board_seq = "";
    /*String userid = "";*/
    private static final String POST = "post";
    private ListView listView;
    private ListViewAdapter listViewAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.comment);
        listView = findViewById(R.id.listView);
        title = findViewById(R.id.title_tv);
        content = findViewById(R.id.content_tv);
        date = findViewById(R.id.date_tv);
        comment_layout = findViewById(R.id.comment_layout);
        comment_et = findViewById(R.id.comment_et);
        reg_button = findViewById(R.id.register2);
        delete_button = findViewById(R.id.delete);

       /* Intent intent = getIntent();
        title.setText(intent.getStringExtra("title"));*/

        Intent intent = getIntent();
        title.setText(intent.getStringExtra("title"));
        Log.d(TAG, "title");
    }
}


/*ListViewItem listviewitem = (ListViewItem) intent.getStringExtra("title");
        title.setText(listviewitem.getTitle());*/
        /*ListViewItem listViewItem =(ListViewItem) getIntent().getExtras().getSerializable("title");*/
        /*title.setText(intent.getStringExtra("title"));*/
        /*String Title= intent.getExtras().getString("title");
          String Content= intent.getExtras().getString("content");
          title.setText(Title);
          content.setText(Content);*/

