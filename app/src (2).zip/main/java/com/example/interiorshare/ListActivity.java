package com.example.interiorshare;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.style.ImageSpan;
import android.util.Log;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.RequiresPermission;
import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Comment;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javax.net.ssl.HttpsURLConnection;

public class ListActivity extends AppCompatActivity {
    ListView listView;
    ListViewAdapter adapter;
    Button but_story;
    String[] SavedFiles;
    ArrayList<ListViewItem> ListViewItem = new ArrayList<>();
    private ListViewItem listViewItem;
    private static final String TAG = "AnonymousAuth";

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.setTitle("List");
        setContentView(R.layout.list);
        but_story = findViewById(R.id.story);
        but_story.setBackgroundColor(getResources().getColor(R.color.pink));
        but_story.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ListActivity.this, WriteActivity.class);
                startActivity(intent);
            }
        });
        showSavedFiles();
    }

    void showSavedFiles() {
        SavedFiles = getApplicationContext().fileList();
        listView = findViewById(R.id.listView);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(ListActivity.this, android.R.layout.simple_list_item_1, SavedFiles);
        listView.setAdapter(adapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                Intent intent = new Intent(ListActivity.this, CommentActivity.class);
                for (int i = 0; i < ListViewItem.size(); i++){
                    ListViewItem listViewItem = (ListViewItem) adapterView.getItemAtPosition(position);
                    intent.putExtra("title", ListViewItem.get(i).getTitle());
                }
                /*intent.putExtra("title", ListViewItem.get(position).getTitle());*/
                startActivity(intent);
            }
        });
    }
}








/* setContentView(R.layout.write);
                but_register.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        String FileTitle = title.getText().toString();
                        String FileContent = content.getText().toString();
                        FileOutputStream fos;
                        try {
                            fos = openFileOutput(FileTitle, Context.MODE_PRIVATE);
                            fos = openFileOutput(FileContent, Context.MODE_PRIVATE);
                            fos.write(title.getText().toString().getBytes());
                            fos.write(content.getText().toString().getBytes());
                            fos.close();
                            Intent intent = new Intent(ListActivity.this, ListActivity.class);
                            startActivity(intent);
                        } catch (FileNotFoundException e) {
                            e.printStackTrace();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        showSavedFiles();
                    }
                });*/

/*    void showSavedFiles() {
        SavedFiles = getApplicationContext().fileList();
        ArrayAdapter<String> adapter
                = new ArrayAdapter<String>(ListActivity.this, android.R.layout.simple_list_item_1, SavedFiles);
        listView.setAdapter(adapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                ListViewItem listViewItem = (ListViewItem) getIntent().getSerializableExtra("title");
                Intent intent = new Intent(ListActivity.this, CommentActivity.class);
                intent.putExtra("title", SavedFiles[position]);
                intent.putExtra("content", SavedFiles[position]);
                Log.d(TAG, "VIEw");
                startActivity(intent);
            }
        });
    }
}*/

