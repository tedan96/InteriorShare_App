package com.example.interiorshare;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;

import javax.net.ssl.HttpsURLConnection;

    public class CommentActivity extends AppCompatActivity {

        final private String TAG = getClass().getSimpleName();

        // 사용할 컴포넌트 선언
        TextView title, content, date;
        LinearLayout comment_layout;
        EditText comment_et;
        Button reg_button;
        ListView listView;

        // 선택한 게시물의 번호
        String board_seq = "";
        // 유저아이디 변수
        /*String userid = "";*/
        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.comment);
// ListActivity 에서 넘긴 변수들을 받아줌

           /* board_seq = getIntent().getStringExtra("board_seq");*/
            /*userid = getIntent().getStringExtra("userid");*/
// 컴포넌트 초기화
            title = findViewById(R.id.title_tv);
            content = findViewById(R.id.content_tv);
            date = findViewById(R.id.date_tv);
            comment_layout = findViewById(R.id.comment_layout);
            comment_et = findViewById(R.id.comment_et);
            reg_button = findViewById(R.id.register2);

            ListViewItem listViewItem =(ListViewItem) getIntent().getExtras().getSerializable("title");
            Intent intent = getIntent();
            title.setText(intent.getStringExtra("title"));

/*          String Title= intent.getExtras().getString("title");
            String Content= intent.getExtras().getString("content");
            title.setText(Title);
            content.setText(Content);*/
            Log.d(TAG,"title");
        }
    }