package com.example.interiorshare;

import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.style.ImageSpan;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.RequiresPermission;
import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Comment;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

import javax.net.ssl.HttpsURLConnection;

public class ListActivity extends AppCompatActivity {
    ListView listView;
    EditText title, content;
    Button button, button2, image;
    ArrayList<String> titleList = new ArrayList<>();
    ArrayList<String> seqList = new ArrayList<>();
    String[] SavedFiles;
    private ListViewItem listViewItem;
    private static final String TAG = "AnonymousAuth";

    public void onCreate(Bundle savedInstancestate) {
        super.onCreate(savedInstancestate);
        setContentView(R.layout.list);
        listView = findViewById(R.id.listView);
        button = findViewById(R.id.story);
        ShowSavedFiles();
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                setContentView(R.layout.write);
                content = findViewById(R.id.content);
                title = findViewById(R.id.title);
                button2 = findViewById(R.id.register);
                button2.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        String fileName = title.getText().toString();
                        String fileContent = content.getText().toString();
                        FileOutputStream fos;
                        try {
                            fos = openFileOutput(fileName, Context.MODE_PRIVATE);
                            fos.write(content.getText().toString().getBytes());
                            fos = openFileOutput(fileContent, Context.MODE_PRIVATE);
                            fos.close();
                            Intent intent = new Intent(ListActivity.this, ListActivity.class);
                            startActivity(intent);
                        } catch (FileNotFoundException e) {
                            e.printStackTrace();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        ShowSavedFiles();
                    }
                });
            }
        });
    }
    void ShowSavedFiles() {
        SavedFiles = getApplicationContext().fileList();
        ArrayAdapter<String> adapter
                = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, SavedFiles);
        listView.setAdapter(adapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                ListViewItem listViewItem =(ListViewItem) getIntent().getSerializableExtra("title");
                Intent intent = new Intent(ListActivity.this, CommentActivity.class);
                intent.putExtra("title", listViewItem);
               /* intent.putExtra("title", SavedFiles[position]);
                intent.putExtra("content", SavedFiles[position]);*/
                Log.d(TAG,"VIEw");
                startActivity(intent);
            }
        });
    }
}
