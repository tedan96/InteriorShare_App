package com.example.interiorshare;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;


import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.Map;

public class ListViewAdapter extends BaseAdapter {

    private ArrayList<ListViewItem> listViewItemList = new ArrayList<ListViewItem>() ;

    public ListViewAdapter() {

    }

    @Override
    public int getCount() {
        return listViewItemList.size() ;
    }

    @Override
    public View getView(int position, View View, ViewGroup parent) {
        final int pos = position;
        final Context context = parent.getContext();

        if (View == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            View = inflater.inflate(R.layout.list, parent, false);
        }
        TextView title = (TextView) View.findViewById(R.id.title_tv) ;
        TextView content = (TextView) View.findViewById(R.id.content_tv) ;

        ListViewItem listViewItem = listViewItemList.get(position);

        title.setText(listViewItem.getTitle());
        content.setText(listViewItem.getContent());
        return View;
    }

    @Override
    public long getItemId(int position) {
        return position ;
    }

    @Override
    public Object getItem(int position) {
        return listViewItemList.get(position) ;
    }

    public void addItem(String title,String content) {
        ListViewItem item = new ListViewItem();
        item.setTitle(title);
        item.setContent(content);
        listViewItemList.add(item);
    }

    public void addItem(String id, Map<String, Object> data) {
        ListViewItem item = new ListViewItem();
        item.setTitle(data.get("title").toString());
        item.setContent(data.get("content").toString());
        Log.d ("tag", "Load from addItem : " + item.getTitle());
        listViewItemList.add(item);
    }

}

