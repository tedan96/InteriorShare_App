package com.example.interiorshare;

import java.io.Serializable;

public class ListViewItem implements Serializable {

    private static final long serialVersionUID = 1L;

    private String titleStr;
    private String contentStr;

    public void setTitle(String title) {
        titleStr = title;
    }
    public void setContent(String content) {contentStr = content; }

    public String getTitle() {
        return this.titleStr;
    }
    public String getContent() {return this.contentStr;}

}

