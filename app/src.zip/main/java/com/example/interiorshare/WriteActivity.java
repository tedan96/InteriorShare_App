package com.example.interiorshare;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ClipData;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.style.ImageSpan;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;

import org.w3c.dom.Text;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;

import javax.net.ssl.HttpsURLConnection;

public class WriteActivity extends AppCompatActivity {
    EditText edit;
    EditText title, content;
    Button button;
    TextView text;
    ListView listView;
    String[] SavedFiles;
/*    @Override
    protected void onCreate(Bundle savedInstancestate) {
        super.onCreate(savedInstancestate);
        setContentView(R.layout.write);
        content = findViewById(R.id.content);
        title = findViewById(R.id.title);
        button = findViewById(R.id.register);
        listView = findViewById(R.id.listView);*/
/*        Drawable d = getResources().getDrawable(R.drawable.ic_launcher_background);
        EditText editText = findViewById(R.id.content);
        ImageSpan imageSpan = new ImageSpan(d, ImageSpan.ALIGN_BASELINE);
        SpannableStringBuilder builder = new SpannableStringBuilder();
        builder.append(editText.getText());
        String imgId = "[img=1]";
        int selStart = editText.getSelectionStart();
        builder.replace(editText.getSelectionStart(), editText.getSelectionEnd(), imgId);
        builder.setSpan(imageSpan, selStart, selStart + imgId.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        editText.setText(builder);*/
       /* ShowSavedFiles();
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String fileName = title.getText().toString();
                String fileContent = content.getText().toString();

                FileOutputStream fos;
                try {
                    fos = openFileOutput(fileName, Context.MODE_PRIVATE);
                    fos.write(content.getText().toString().getBytes());
                    fos.close();
                    Toast.makeText(WriteActivity.this, fileName + " saved",Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(WriteActivity.this, ListActivity.class);
                    startActivity(intent);
                } catch (FileNotFoundException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                } catch (IOException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
                ShowSavedFiles();
            }});
            }
    void ShowSavedFiles(){
        SavedFiles = getApplicationContext().fileList();
        ArrayAdapter<String> adapter
                = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1, SavedFiles);
        listView.setAdapter(adapter);*/
    /*}*/
}


